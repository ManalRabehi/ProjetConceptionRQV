public interface Utilisateur {
    public void update();
}
