import java.time.LocalDate;
import java.time.LocalTime;

public class DeclarationDeVol {
    public DeclarationDeVol(ProprieteVolee propriete, LocalDate dateVol, LocalTime heureVol, String lieu, String description) {
    }
}
