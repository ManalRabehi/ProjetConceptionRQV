public enum Role {
    Victime, Temoin, VictimeEtTemoin;
}
