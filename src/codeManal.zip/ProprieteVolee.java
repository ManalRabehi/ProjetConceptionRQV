public class ProprieteVolee {
}
